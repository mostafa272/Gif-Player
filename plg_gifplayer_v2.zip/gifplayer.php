﻿<?php
/**
 * Gif Player V2 Plugin for Joomla 3.0
 * License: http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @author Mostafa Shahiri
*/
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.plugin.plugin' );

class plgContentGifplayer extends JPlugin {

	function onContentPrepare($context, &$article, &$params, $page=0)
	{
    $label=$this->params->get('labelimg');
       $document = JFactory::getDocument();
$document->addStyleSheet('plugins/content/gifplayer/css/style.css');
$document->addScript('https://code.jquery.com/jquery-1.11.2.min.js');
$document->addScript( 'plugins/content/gifplayer/js/script.js');
$script="$(document).ready( function(){
				$('.gifplayer').gifplayer({label:'".$label."'});

			});";
$document->addCustomTag( '<script type="text/javascript">'.$script.'</script>' );
    $hover=$this->params->get('hover');
       $wait=$this->params->get('wait');
       $width=$this->params->get('width');
       $height=$this->params->get('height');
       $found=preg_match_all('#<img(.*?)src="(.*?).gif"(.*?)>#i', $article->text, $images);
       if($found){
       foreach ($images[0] as $img)
       {
       $s=preg_match_all('#src="(.*?)"#s', $img, $src);
       if($s)
       {
       foreach( $src[0] as $sr)
       {
       $tmpsrc1=str_replace('src="','',$sr);
       $tmpsrc2=str_replace('.gif"','.jpg',$tmpsrc1);
       if(!file_exists($tmpsrc2))
       { $gifimg = imagecreatefromgif(substr($tmpsrc1,0,-1));
       imagejpeg($gifimg,$tmpsrc2);
       imagedestroy($gifimg);
       }
       }
       }
       $f=preg_match_all('#class="(.*?)"#s', $img, $class);
       if($f)
       {
       foreach( $class[0] as $c)
       {
       $img1=preg_replace('#'.$c.'#s',substr($c,0,-1).' gifplayer"',$img);
       }
       }
       else{
       $img1=preg_replace('#'.$img.'#s',substr($img,0,-2).' class="gifplayer" />',$img);
       }
       $article->text=preg_replace('#'.$img.'#s',$img1,$article->text);
       $a='';
       if($hover)
       $a=' data-playon="hover"';
       if($wait)
       $a=$a.' data-wait="true"';
       if(!empty($width))
       $a=$a.' width="'.$width.'"';
       if(!empty($height))
       $a=$a.' height="'.$height.'"';
       $article->text=preg_replace('#'.$img1.'#s',substr($img1,0,-2).$a.'/>',$article->text);
 }
 $article->text=str_replace('.gif','.jpg',$article->text);
 }

     }
  }
